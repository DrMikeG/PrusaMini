                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


http://www.thingiverse.com/thing:627496
Butterfly wall decoration by dfunk is licensed under the Creative Commons - Attribution - Share Alike license.
http://creativecommons.org/licenses/by-sa/3.0/

# Summary

Minor update (April 2017) Added a better connection between the wings and base, created more distance between the hinge components to reduce the likelyhood of fusion, and added incorporated build plate adhesion that won't interfere with the hinge functioning.  So you don't need to print this with a raft, it should hold better to the build plate.   Also moved to thinner wings to increase the print speed.  Latest tests are with a JellyBox with an unheated bed, and prints seem to hold better and hinges work right off the plate without modification.  

Inspired by Mentalist, this is a butterfly wall decoration I created over Christmas for a very beautiful woman I know.   It prints with an in-place hinge so you can open it up various amounts to give lots of different looks.  It prints vertically with the hinge closed, to make removal very easy.  It doesn't require you to print a raft, and the butterfly pop right off the plate very cleanly.  

The butterfly14 file will print 14 butterflys simultaniously.